/**
 * WordPrtess dependencies
 */
import {list} from '@wordpress/icons';
import {__} from '@wordpress/i18n';

/**
 * Internal depedencies
 */
import attributes from './attributes';
import edit from './edit';
import './editor.scss';
import {SVGIcon} from "../../utils/icons";

export {default as metadata} from './block.json'

export const settings = {
    title: __('Order Details', 'funnel-builder'),
    keywords: [
        __('Woofunnels', 'funnel-builder'),
        __('Order Details', 'funnel-builder'),
        __('Thank you', 'funnel-builder'),
    ],
    icon: <SVGIcon icon={"order-details"}/>,
    title: __("Order Details", 'funnel-builder'),
    category: 'woofunnels',
    supports: {
        anchor: true,
    },
    attributes,
    edit,
};
