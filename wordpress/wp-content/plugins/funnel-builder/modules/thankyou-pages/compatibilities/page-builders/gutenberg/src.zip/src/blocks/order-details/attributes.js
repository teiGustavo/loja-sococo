const attributes = {
	orderHeading: {
		type: 'string',
		default: 'Order Details',
	},
	subscriptionHeading: {
		type: 'string',
		default: 'Subscription',
	},
	subscriptionPreview: {
		type: 'boolean',
		default: false,
	},
	downloadHeading: {
		type: 'string',
		default: 'Downloads',
	},
	downloadBtnText: {
		type: 'string',
		default: 'Download',
	},
	downloadPreview: {
		type: 'string',
		default: false,
	},
	downloadFileCount: {
		type: 'boolean',
		default: false,
	},
	showDownloadPreview: {
		type: 'boolean',
		default: false,
	},
	downloadFileExpiry: {
		type: 'boolean',
		default: false,
	},
	orderProductImage: {
		type: 'boolean',
		default: true,
	},
	headingTextStyle: {
		type: 'object',
	},
	headingFont: {
		type: 'object',
	},
	headingLetterSpacing: {
		type: 'object',
	},
	headingLineHeight: {
		type: 'object',
	},
	headingColor: {
		type: 'object',
		default: {
			desktop: '#000000',
		},
	},
	productTextStyle: {
		type: 'object',
	},
	productFont: {
		type: 'object',
	},
	productLetterSpacing: {
		type: 'object',
	},
	productLineHeight: {
		type: 'object',
	},
	productColor: {
		type: 'object',
		default: {
			desktop: '#565656',
		},
	},
	subTotalTextStyle: {
		type: 'object',
	},
	subTotalFont: {
		type: 'object',
	},
	subTotalLetterSpacing: {
		type: 'object',
	},
	subTotalLineHeight: {
		type: 'object',
	},
	subTotalColor: {
		type: 'object',
		default: {
			desktop: '#565656',
		},
	},
	totalTextStyle: {
		type: 'object',
	},
	totalFont: {
		type: 'object',
	},
	totalLetterSpacing: {
		type: 'object',
	},
	totalLineHeight: {
		type: 'object',
	},
	totalColor: {
		type: 'object',
		default: {
			desktop: '#565656',
		},
	},
	variationTextStyle: {
		type: 'object',
	},
	variationFont: {
		type: 'object',
	},
	variationLetterSpacing: {
		type: 'object',
	},
	variationLineHeight: {
		type: 'object',
	},
	variationColor: {
		type: 'object',
		default: {
			desktop: '#000000',
		},
	},
	dividerColor: {
		type: 'object',
		default: {
			desktop: '#dddddd',
		},
	},
	subscriptionTextStyle: {
		type: 'object',
	},
	subscriptionFont: {
		type: 'object',
		default: {
			desktop: {
				size: 15,
				sizeUnit: 'px',
			},
		},
	},
	subscriptionLetterSpacing: {
		type: 'object',
	},
	subscriptionLineHeight: {
		type: 'object',
	},
	subscriptionColor: {
		type: 'object',
		default: {
			desktop: '#565656',
		},
	},
	subscriptionBtnColor: {
		type: 'object',
		default: {
			desktop: '#ffffff',
		},
	},
	subscriptionBtnColorHover: {
		type: 'object',
	},
	subscriptionBtnBackground: {
		type: 'object',
		default: {
			desktop: '#70dc1d',
		},
	},
	subscriptionBtnBackgroundHover: {
		type: 'object',
	},
	downloadTextStyle: {
		type: 'object',
	},
	downloadFont: {
		type: 'object',
		default: {
			desktop: {
				size: 15,
				sizeUnit: 'px',
			},
		},
	},
	downloadLetterSpacing: {
		type: 'object',
	},
	downloadLineHeight: {
		type: 'object',
	},
	downloadColor: {
		type: 'object',
		default: {
			desktop: '#565656',
		},
	},
	downloadBtnColor: {
		type: 'object',
		default: {
			desktop: '#ffffff',
		},
	},
	downloadBtnColorHover: {
		type: 'object',
	},
	downloadBtnBackground: {
		type: 'object',
		default: {
			desktop: '#70dc1d',
		},
	},
	downloadBtnBackgroundHover: {
		type: 'object',
	},
};
export default attributes;
