import {registerPlugin, getPlugin, unregisterPlugin} from '@wordpress/plugins';
import {BWFLogoSVG} from '../utils/icons';
import BWFConfig from './config';
import {addFilter} from '@wordpress/hooks';
import BWFSidebarPanel from './panel';
import {__} from '@wordpress/i18n/build-types';
import './editor.scss';

// Check Compatibility with slingblock sidebar
wp.domReady(function () {
    if (wp.plugins.getPlugin('slingblock-plugin')) {
        wp.plugins.unregisterPlugin('slingblock-plugin');
    }
});

registerPlugin('bwfblocks-plugins', {
    icon: BWFLogoSVG(),
    render: BWFConfig,
});
