const attributes = {
	content: {
		type: 'string',
		default: 'Customer Details'
	},
	layout: {
		type: 'object',
		default: {
			desktop: '2c'
		}
	},
	headingText: {
		type: 'object'
	},
	headingFont: {
		type: 'object'
	},
	headingLetterSpacing: {
		type: 'object'
	},
	headingLineHeight: {
		type: 'object'
	},
	headingColor: {
		type: 'object',
		default: {
			desktop: '#333333'
		}
	},
	subHeadingText: {
		type: 'object'
	},
	subHeadingFont: {
		type: 'object'
	},
	subHeadingLetterSpacing: {
		type: 'object'
	},
	subHeadingLineHeight: {
		type: 'object'
	},
	subHeadingColor: {
		type: 'object',
		default: {
			desktop: '#333333'
		}
	},
	contentText: {
		type: 'object'
	},
	contentFont: {
		type: 'object'
	},
	contentLetterSpacing: {
		type: 'object'
	},
	contentLineHeight: {
		type: 'object'
	},
	contentColor: {
		type: 'object',
		default: {
			desktop: '#565656'
		}
	},
};
export default attributes;
